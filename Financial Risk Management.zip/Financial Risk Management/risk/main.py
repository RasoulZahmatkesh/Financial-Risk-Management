"""
AI Risk Management Framework
Main Runner
Run: python main.py
"""

from pathlib import Path
import json
from risk.capital_manager import CapitalManager
from risk.money_manager import MoneyManager
from risk.position_size import PositionManager
from risk.portfolio_risk import PortfolioManager
from risk.leverage import LeverageManager
from risk.drawdown_manager import DrawdownManager
from risk.risk_validator import RiskValidator
from risk.risk_report import RiskReport
from risk.ai import AIRiskEngine


class RiskApplication:

    def __init__(self):

        self.account = {
            "balance": 10000,
            "equity": 10000,
            "daily_loss": 1.5,
            "weekly_loss": 3,
            "monthly_loss": 5,
            "drawdown": 2
        }

        self.trade = {
            "entry_price": 31000,
            "stop_loss": 30500,
            "take_profit": 32000,
            "risk_percent": 1,
            "leverage": 5,
            "side": "LONG"
        }

        self.portfolio = {
            "portfolio_risk": 2.5,
            "open_positions": 3,
            "symbol_positions": 1,
            "total_exposure": 30
        }

    def run(self):
        print("=" * 60)
        print(" AI RISK MANAGEMENT FRAMEWORK ")
        print("=" * 60)
        
        capital = CapitalManager()
        money = MoneyManager()
        position = PositionManager()
        portfolio = PortfolioManager()
        leverage = LeverageManager()
        drawdown = DrawdownManager()
        validator = RiskValidator()
        ai = AIRiskEngine()
        report = RiskReport()
        
        capital_result = capital.summary(self.account)
        
        money_result = money.calculate(
            balance=self.account["balance"],
            risk_percent=self.trade["risk_percent"],
            entry_price=self.trade["entry_price"],
            stop_loss=self.trade["stop_loss"])
        
        position_result = position.calculate(balance=self.account["balance"],
            risk_percent=self.trade["risk_percent"],
            entry=self.trade["entry_price"],
            stop=self.trade["stop_loss"])
        
        portfolio_result = portfolio.summary(self.portfolio)
        leverage_result = leverage.summary(leverage=self.trade["leverage"],
            entry_price=self.trade["entry_price"])
        drawdown_result = drawdown.summary(self.account)
        validation = validator.validate_all(self.trade,
            self.portfolio,
            self.account)
        
        ai_result = ai.predict(account=self.account,
            portfolio=self.portfolio,
            trade=self.trade)
        
        final_report = report.generate(account=self.account,
            portfolio=self.portfolio,
            positions=[],
            statistics={},
            limits=validator.limits)
        final_report["capital"] = capital_result
        final_report["money"] = money_result
        final_report["position"] = position_result
        final_report["portfolio"] = portfolio_result
        final_report["leverage"] = leverage_result
        final_report["drawdown"] = drawdown_result
        final_report["validation"] = validation
        final_report["ai"] = ai_result
        self.print_console(final_report)
        Path("reports").mkdir(exist_ok=True)
        with open("reports/risk_report.json", "w") as f:
            json.dump(final_report, f, indent=4)
        print("\nJSON Report Saved -> reports/risk_report.json")
    @staticmethod
    def print_console(data):
        print("\nACCOUNT")
        print("-" * 60)
        for key, value in data["account"].items():
            print(f"{key:25} {value}")
        print("\nAI")
        print("-" * 60)
        for key, value in data["ai"].items():
            print(f"{key:25} {value}")
        print("\nVALIDATION")
        print("-" * 60)
        
        if data["validation"]["valid"]:
            print("TRADE ACCEPTED")
        else:
            print("TRADE REJECTED")
            
            for error in data["validation"]["errors"]:
                print("-", error)
        print("\nRISK SCORE")
        print("-" * 60)
        print(data["risk_score"])
        print("=" * 60)
        
if __name__ == "__main__":
    app = RiskApplication()
    app.run()