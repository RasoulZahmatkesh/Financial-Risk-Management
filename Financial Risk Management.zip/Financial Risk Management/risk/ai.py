from dataclasses import dataclass

@dataclass
class AIResult:
    recommended_risk: float
    position_size: float
    win_probability: float
    confidence: float
    market_regime: str
    volatility: str
    
class AIRiskEngine:
    """
    Rule-Based AI Risk Engine
    Version 1.0
    This class provides intelligent risk recommendations based on
    account status, drawdown, portfolio exposure and trade settings.
    In future versions, this engine can be replaced by a Machine Learning
    model without changing the public API.
    """
    def __init__(self):
        pass
    
    def predict(self, account: dict, portfolio: dict, trade: dict) -> dict:
        balance = account.get("balance", 0)
        drawdown = account.get("drawdown", 0)
        exposure = portfolio.get("total_exposure", 0)
        risk_percent = trade.get("risk_percent", 1)
        entry = trade.get("entry_price", 1)
        stop = trade.get("stop_loss", entry)
        
        # Market Regime
        if exposure < 25:
            regime = "LOW VOLATILITY"
        elif exposure < 50:
            regime = "TRENDING"
        else:
            regime = "HIGH VOLATILITY"
        
        # Recommended Risk
        recommended_risk = risk_percent
        if drawdown > 10:
            recommended_risk *= 0.50
        elif drawdown > 5:
            recommended_risk *= 0.75
        if exposure > 50:
            recommended_risk *= 0.80
        recommended_risk = round(recommended_risk, 2)
        
        # Position Size
        risk_amount = balance * (recommended_risk / 100)
        stop_distance = abs(entry - stop)
        if stop_distance == 0:
            position_size = 0
        else:
            position_size = risk_amount / stop_distance
        position_size = round(position_size, 4)
    
    # Win Probability
        win_probability = 80
        if drawdown > 5:
            win_probability -= 5
        if exposure > 50:
            win_probability -= 5
        win_probability = max(50, min(95, win_probability))
    
    # Confidence
        confidence = 95
        confidence -= drawdown
        confidence -= exposure * 0.10
        confidence = max(50, min(99, confidence))
    
    # Volatility
        if exposure < 25:
            volatility = "LOW"
        elif exposure < 50:
            volatility = "MEDIUM"
        else:
            volatility = "HIGH"
        result = AIResult(recommended_risk=recommended_risk, position_size=position_size, win_probability=win_probability,
            confidence=round(confidence, 1), market_regime=regime, volatility=volatility)
        return result.__dict__
    
    def predict_risk(self, drawdown: float, exposure: float, current_risk: float) -> float:
        
        """
        Predict recommended risk percentage.
        """
        
        risk = current_risk
        if drawdown > 10:
            risk *= 0.5
        elif drawdown > 5:
            risk *= 0.75
        if exposure > 50:
            risk *= 0.8
        return round(risk, 2)
    
    def confidence_score(self, drawdown: float, exposure: float) -> float:
        
        """
        Calculate confidence score.
        """
        
        score = 95
        score -= drawdown
        score -= exposure * 0.1
        return round(max(50, min(99, score)), 1)